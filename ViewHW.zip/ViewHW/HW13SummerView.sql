CREATE VIEW sales.SummerYearlySales
AS
SELECT
	DATEPART(YEAR, SOH.OrderDate)		     AS Years,
	SUM(
	CASE
		WHEN DATEPART (QUARTER, SOH.OrderDate) = 3 
		THEN SOD.LineTotal
		Else 0
		End )   AS Summer
FROM
	Sales.SalesOrderHeader					 AS SOH
INNER JOIN
	Sales.SalesOrderDetail					 AS SOD
ON
	SOH.SalesOrderID = SOD.SalesOrderID
GROUP BY
	DATEPART(YEAR, SOH.OrderDate)
