SELECT
	Winter.Years,
	Winter.Winter,
	Spring.Spring,
	Summer.Summer,
	Fall.Fall
FROM
	Sales.WinterYearlySales			AS  Winter
INNER JOIN
	Sales.SpringYearlySales			AS Spring
ON
	Winter.Years = Spring.Years
INNER JOIN
	Sales.SummerYearlySales			AS Summer
ON
	Summer.Years = Spring.Years
INNER JOIN
	Sales.FallYearlySales			AS Fall
ON
	Summer.Years = Fall.Years
ORDER By
	1