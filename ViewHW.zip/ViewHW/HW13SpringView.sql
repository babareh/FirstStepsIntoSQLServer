CREATE VIEW sales.SpringYearlySales
AS
SELECT
	DATEPART(YEAR, SOH.OrderDate)		     AS Years,
	SUM(
	CASE
		WHEN DATEPART (QUARTER, SOH.OrderDate) = 2 
		THEN SOD.LineTotal
		Else 0
		End )   AS Spring
FROM
	Sales.SalesOrderHeader					 AS SOH
INNER JOIN
	Sales.SalesOrderDetail					 AS SOD
ON
	SOH.SalesOrderID = SOD.SalesOrderID
GROUP BY
	DATEPART(YEAR, SOH.OrderDate)
