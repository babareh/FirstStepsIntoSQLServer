CREATE VIEW sales.FallYearlySales
AS
SELECT
	DATEPART(YEAR, SOH.OrderDate)		     AS Years,
	SUM(
	CASE
		WHEN DATEPART (QUARTER, SOH.OrderDate) = 4 
		THEN SOD.LineTotal
		Else 0
		End )   AS Fall
FROM
	Sales.SalesOrderHeader					 AS SOH
INNER JOIN
	Sales.SalesOrderDetail					 AS SOD
ON
	SOH.SalesOrderID = SOD.SalesOrderID
GROUP BY
	DATEPART(YEAR, SOH.OrderDate)
